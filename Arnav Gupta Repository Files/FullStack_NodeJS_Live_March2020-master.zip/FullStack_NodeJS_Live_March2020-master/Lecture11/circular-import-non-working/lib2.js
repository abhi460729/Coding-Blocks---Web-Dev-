const lib1 = require('./lib1')


module.exports = {
    b: 20, 
    lib1
}