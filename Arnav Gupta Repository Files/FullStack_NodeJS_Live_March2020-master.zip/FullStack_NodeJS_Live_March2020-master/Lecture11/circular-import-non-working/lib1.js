const lib2 = require('./lib2')
console.log('xxxxx', module.exports)
module.exports = {
    a: 10,
    lib2
}
console.log('xxxxx', module.exports)
