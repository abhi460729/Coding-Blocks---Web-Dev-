module.exports.a = 10
module.exports.lib2 = require('./lib2')
module.exports.fun1 = function () {
    console.log('yay!')
}