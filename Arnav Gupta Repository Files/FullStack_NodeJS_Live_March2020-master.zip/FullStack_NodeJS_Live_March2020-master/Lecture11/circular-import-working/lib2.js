module.exports.b = 20
module.exports.lib1 = require('./lib1')