function foo () {
    console.log(this.a)
}
let a = 5 
foo () 
