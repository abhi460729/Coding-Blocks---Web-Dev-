console.log('external script')
alert('ext src')