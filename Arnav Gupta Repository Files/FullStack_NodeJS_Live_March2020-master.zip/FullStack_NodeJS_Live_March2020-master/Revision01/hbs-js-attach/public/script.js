window.onload = function () {
  window.alert('Hi! Page has loaded')
}