const { Router } = require('express')

const commentsRoute = Router()

module.exports = {
  commentsRoute
}