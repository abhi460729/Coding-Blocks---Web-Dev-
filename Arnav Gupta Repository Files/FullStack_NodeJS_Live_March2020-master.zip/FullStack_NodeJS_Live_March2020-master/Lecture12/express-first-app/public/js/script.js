window.onload = function () {
    alert('Welcome to ' + window.location.href)
}