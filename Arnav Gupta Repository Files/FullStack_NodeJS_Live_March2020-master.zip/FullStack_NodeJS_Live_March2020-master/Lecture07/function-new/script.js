function Person (name, age) {
    this.name = name 
    this.age = age
}

function Student () {

}

let p1 = new Person('John Doe', 22)